function add1(a, b) {
    return a + b;
}
console.log(add1("Hello ", "Steve")); // returns "Hello Steve" 
console.log(add1(10, 20)); // returns 30 
console.log(add1(10.5, 20)); // returns 30 
